#include <iostream>

using namespace std;

int main(){
        // How many CU students does it take to change a light bulb?
        cout << "Just one! I have friends at CU and I don't want to throw shade at them :(\n";
        return 0;
}

